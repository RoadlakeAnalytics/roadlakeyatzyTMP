import os


class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'en-mycket-hemlig-nyckel'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///yatzy.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
