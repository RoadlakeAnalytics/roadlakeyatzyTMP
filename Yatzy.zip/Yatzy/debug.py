import os
from flask import Flask, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import OperationalError


def check_file(file_path):
    exists = os.path.exists(file_path)
    print(f"[{'OKEJ' if exists else 'PROBLEM'}] Filen {file_path} finns")
    if exists:
        with open(file_path, 'r') as f:
            content = f.read()
            print(f"[INFO] Innehåll av {file_path}:")
            print(content)
            print("-" * 50)


def check_folder_structure(required_folders):
    for folder in required_folders:
        exists = os.path.exists(folder)
        print(f"[{'OKEJ' if exists else 'PROBLEM'}] Mappen {folder} finns")


def check_files(required_files):
    for file in required_files:
        check_file(file)


def check_flask_app():
    try:
        app = Flask(__name__)
        app.config.from_object('config.Config')
        db = SQLAlchemy(app)
        print("[OKEJ] Flask-app kunde skapas och databasen initieras")
        return app, db
    except Exception as e:
        print(
            f"[PROBLEM] Kunde inte skapa Flask-app eller initiera databas: {str(e)}")
        return None, None


def check_database_connection(app, db):
    try:
        with app.app_context():
            db.engine.connect()
        print("[OKEJ] Databasen är tillgänglig")
    except OperationalError:
        print("[PROBLEM] Kunde inte ansluta till databasen. Kontrollera att databasen finns och att sökvägen är korrekt.")


def check_blueprints(app):
    try:
        registered_blueprints = [str(bp) for bp in app.blueprints]
        print(
            f"[OKEJ] Registrerade blueprints: {', '.join(registered_blueprints)}")
    except Exception as e:
        print(f"[PROBLEM] Kunde inte kontrollera blueprints: {str(e)}")


def check_models():
    try:
        from app.models import User, Game, Score, PlayerStatistics, RoadlakeStatistics
        print("[OKEJ] Modeller kunde importeras")
    except ImportError:
        print("[PROBLEM] Kunde inte importera modeller från app.models")


def check_routes(app):
    try:
        with app.test_request_context():
            print(f"[OKEJ] Rotrutt: {url_for('game.index')}")
            print(f"[OKEJ] Spelrutt: {url_for('game.play', game_id=1)}")
    except Exception as e:
        print(f"[PROBLEM] Kunde inte generera URL:er för rutter: {str(e)}")


def check_game_logic():
    try:
        from app.static.js.game import rollDice
        print("[OKEJ] Funktion rollDice är tillgänglig i game.js")
    except ImportError:
        print("[PROBLEM] Kunde inte hitta rollDice-funktionen i game.js")

    try:
        from app.game.routes import play
        print("[OKEJ] Spelruttens play-funktion är definierad")
    except ImportError:
        print("[PROBLEM] Kunde inte importera play-funktionen från app.game.routes")


def check_dice_roll_logic():
    try:
        with open('app/static/js/game.js', 'r') as f:
            content = f.read()
            if 'selectedDice' in content and 'diceToRoll' in content:
                print("[OKEJ] Vald tärningslogik verkar vara närvarande i game.js")
            else:
                print(
                    "[PROBLEM] Tärningslogik verkar saknas eller vara felaktig i game.js")
    except Exception as e:
        print(
            f"[PROBLEM] Kunde inte läsa tärningslogik från game.js: {str(e)}")


if __name__ == '__main__':
    # Kontrollera om konfigurationsfilen finns
    check_file('config.py')

    # Försök att skapa en Flask-app och initiera databasen
    app, db = check_flask_app()

    if app and db:
        # Kontrollera om databasen finns och är tillgänglig
        check_database_connection(app, db)

        # Kontrollera om nödvändiga mappar finns
        check_folder_structure(['app', 'app/templates', 'app/static'])

        # Kontrollera om nödvändiga filer finns och visa innehållet
        check_files([
            'app/__init__.py', 'app/models.py', 'app/auth/routes.py',
            'app/game/routes.py', 'app/game/utils.py',
            'app/templates/base.html', 'app/templates/game/play.html',
            'app/static/js/game.js', 'run.py'
        ])

        # Kontrollera om blueprints är korrekt registrerade
        check_blueprints(app)

        # Kontrollera om modeller är korrekt definierade
        check_models()

        # Kontrollera om rutter är definierade
        check_routes(app)

        # Kontrollera om spel- och tärningslogik fungerar korrekt
        check_game_logic()
        check_dice_roll_logic()
