from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///yatzy.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))


class Game(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    game_type = db.Column(db.String(20), nullable=False)
    start_time = db.Column(db.DateTime, default=datetime.utcnow)
    end_time = db.Column(db.DateTime)
    current_player_index = db.Column(db.Integer, default=0)
    current_roll = db.Column(db.PickleType, nullable=True)


class GamePlayers(db.Model):
    game_id = db.Column(db.Integer, db.ForeignKey('game.id'), primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), primary_key=True)


class Score(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    game_id = db.Column(db.Integer, db.ForeignKey('game.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    category = db.Column(db.String(64), nullable=False)
    value = db.Column(db.Integer, nullable=False)


class RollHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    game_id = db.Column(db.Integer, db.ForeignKey('game.id'), nullable=False)
    roll_number = db.Column(db.Integer, nullable=False)
    rolls = db.Column(db.PickleType, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)


class PlayerStatistics(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    games_played = db.Column(db.Integer, default=0)
    total_score = db.Column(db.Integer, default=0)
    highest_score = db.Column(db.Integer, default=0)
    yatzy_count = db.Column(db.Integer, default=0)


class RoadlakeStatistics(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    games_played = db.Column(db.Integer, default=0)
    total_score = db.Column(db.Integer, default=0)
    highest_score = db.Column(db.Integer, default=0)
    special_dice_used_count = db.Column(db.Integer, default=0)


def create_sample_data():
    # Skapa några användare
    user1 = User(name="Alice")
    user1.password_hash = generate_password_hash("password123")
    user2 = User(name="Bob")
    user2.password_hash = generate_password_hash("password456")
    db.session.add_all([user1, user2])
    db.session.commit()

    # Skapa ett spel
    game = Game(game_type="classic")
    db.session.add(game)
    db.session.commit()

    # Lägg till spelare till spelet
    db.session.add_all([
        GamePlayers(game_id=game.id, user_id=user1.id),
        GamePlayers(game_id=game.id, user_id=user2.id)
    ])
    db.session.commit()

    # Skapa några poäng
    score1 = Score(game_id=game.id, user_id=user1.id,
                   category="Ettor", value=3)
    score2 = Score(game_id=game.id, user_id=user2.id,
                   category="Tvåor", value=6)
    db.session.add_all([score1, score2])
    db.session.commit()

    # Skapa statistik för spelarna
    stats1 = PlayerStatistics(user_id=user1.id, games_played=1, total_score=3)
    stats2 = PlayerStatistics(user_id=user2.id, games_played=1, total_score=6)
    roadlake_stats1 = RoadlakeStatistics(user_id=user1.id, games_played=0)
    roadlake_stats2 = RoadlakeStatistics(user_id=user2.id, games_played=0)
    db.session.add_all([stats1, stats2, roadlake_stats1, roadlake_stats2])
    db.session.commit()


if __name__ == '__main__':
    with app.app_context():
        # Drop all tables if they exist and create new ones
        db.drop_all()
        db.create_all()
        print("Alla nödvändiga tabeller har skapats.")

        # Kontrollera om det finns några användare
        if User.query.count() == 0:
            create_sample_data()
            print("Exempeldata har skapats.")
        else:
            print("Databasen innehåller redan data.")
