def calculate_score(category, rolls):
    counts = {i: rolls.count(i) for i in range(1, 7)}

    if category in ['Ettor', 'Tvåor', 'Treor', 'Fyror', 'Femmor', 'Sexor']:
        value = ['Ettor', 'Tvåor', 'Treor', 'Fyror',
                 'Femmor', 'Sexor'].index(category) + 1
        return value * counts[value]

    elif category == 'Ett par':
        for i in range(6, 0, -1):
            if counts[i] >= 2:
                return i * 2

    elif category == 'Två par':
        pairs = [i for i in range(6, 0, -1) if counts[i] >= 2]
        if len(pairs) >= 2:
            return pairs[0] * 2 + pairs[1] * 2

    elif category == 'Tretal':
        for i in range(6, 0, -1):
            if counts[i] >= 3:
                return i * 3

    elif category == 'Fyrtal':
        for i in range(6, 0, -1):
            if counts[i] >= 4:
                return i * 4

    elif category == 'Liten stege':
        if all(counts[i] >= 1 for i in range(1, 6)):
            return 15

    elif category == 'Stor stege':
        if all(counts[i] >= 1 for i in range(2, 7)):
            return 20

    elif category == 'Kåk':
        three = next((i for i in range(6, 0, -1) if counts[i] >= 3), None)
        two = next((i for i in range(6, 0, -1)
                   if counts[i] >= 2 and i != three), None)
        if three and two:
            return three * 3 + two * 2

    elif category == 'Chans':
        return sum(i * counts[i] for i in range(1, 7))

    elif category == 'Yatzy':
        if 5 in counts.values():
            return 50

    return 0
