from flask_wtf import FlaskForm
from wtforms import SelectMultipleField, SubmitField, RadioField
from wtforms.validators import DataRequired, Length
from app.models import User


class GameSetupForm(FlaskForm):
    players = SelectMultipleField('Välj spelare', coerce=int, validators=[
                                  DataRequired(), Length(min=1, max=4)])
    game_type = RadioField('Speltyp', choices=[(
        'classic', 'Klassisk Yatzy'), ('roadlake', 'RoadlakeYatzy')], default='classic')
    submit = SubmitField('Börja spela!')

    def __init__(self, *args, **kwargs):
        super(GameSetupForm, self).__init__(*args, **kwargs)
        self.players.choices = [(user.id, user.name)
                                for user in User.query.all()]
