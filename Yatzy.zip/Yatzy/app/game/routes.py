from flask import render_template, request, jsonify, redirect, url_for, flash
from flask_login import login_required, current_user
from app.game import bp
from app.game.forms import GameSetupForm
from app.models import Game, Score, User, PlayerStatistics, RoadlakeStatistics, RollHistory, YATZY_CATEGORIES
from app.game.utils import calculate_score
from app import db
import random
import logging

logging.basicConfig(filename='yatzy_game.log', level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - %(message)s')


@bp.route('/', methods=['GET', 'POST'])
@login_required
def index():
    form = GameSetupForm()
    if form.validate_on_submit():
        players = [User.query.get(player_id)
                   for player_id in form.players.data]
        game = Game(players=players, game_type=form.game_type.data)
        db.session.add(game)
        db.session.commit()
        return redirect(url_for('game.play', game_id=game.id))
    return render_template('game/index.html', title='Yatzy', form=form)


@bp.route('/play/<int:game_id>', methods=['GET', 'POST'])
@login_required
def play(game_id):
    game = Game.query.get_or_404(game_id)
    logging.info(
        f"Accessing game {game_id} - Current player: {game.current_player().name}")

    if current_user not in game.players:
        flash('Du har inte tillåtelse att delta i detta spel.', 'error')
        return redirect(url_for('game.index'))

    if request.method == 'POST':
        action = request.form.get('action')
        logging.info(
            f"POST request received for game {game_id} - Action: {action}")

        if action == 'roll':
            reroll_indices = [int(i)
                              for i in request.form.getlist('reroll_indices[]')]
            logging.info(f"Reroll indices: {reroll_indices}")

            current_roll = game.current_roll or [0, 0, 0, 0, 0]
            logging.info(f"Current roll before reroll: {current_roll}")

            for i in range(5):
                if i in reroll_indices or current_roll[i] == 0:
                    current_roll[i] = random.randint(1, 6)
                logging.info(
                    f"Tärning {i+1}: {'omkastad' if i in reroll_indices or current_roll[i] == 0 else 'behållen'}, nytt värde: {current_roll[i]}")

            game.current_roll = current_roll
            db.session.commit()
            logging.info(f"New roll: {current_roll}")

            options = {category: calculate_score(
                category, current_roll) for category in YATZY_CATEGORIES}
            logging.info(f"Calculated options: {options}")
            return jsonify({'status': 'success', 'rolls': current_roll, 'options': options})

        elif action == 'save':
            category = request.form.get('category')
            score = int(request.form.get('score'))

            # Kontrollera om kategorin redan har poäng för denna spelare
            existing_score = Score.query.filter_by(
                game_id=game.id, user_id=current_user.id, category=category).first()
            if existing_score:
                logging.warning(
                    f"Attempt to overwrite existing score - Game ID: {game_id}, Player: {current_user.name}, Category: {category}")
                return jsonify({'status': 'error', 'message': 'Du har redan poäng i denna kategori.'})

            logging.info(
                f"Saving score - Game ID: {game_id}, Player: {current_user.name}, Category: {category}, Score: {score}")

            new_score = Score(
                game_id=game.id, user_id=current_user.id, category=category, value=score)
            db.session.add(new_score)

            game.current_roll = None
            game.next_player()
            db.session.commit()
            logging.info(
                f"Score saved and next player set - Next player: {game.current_player().name}")

            return jsonify({'status': 'success'})

    game_state = {
        'current_player': {
            'id': game.current_player().id,
            'name': game.current_player().name
        },
        'scores': game.get_scores(),
        'is_finished': game.is_finished(),
        'categories': YATZY_CATEGORIES,
        'current_roll': game.current_roll if game.current_roll else [],
        'game_type': game.game_type
    }
    logging.info(f"Game state: {game_state}")
    return render_template('game/play.html', title='Spela Yatzy', game=game, game_state=game_state)


@bp.route('/game_state/<int:game_id>')
@login_required
def game_state(game_id):
    game = Game.query.get_or_404(game_id)
    if current_user not in game.players:
        return jsonify({'status': 'error', 'message': 'Otillåten åtgärd'}), 403
    return jsonify({
        'current_player': {
            'id': game.current_player().id,
            'name': game.current_player().name
        },
        'scores': game.get_scores(),
        'is_finished': game.is_finished(),
        'categories': YATZY_CATEGORIES,
        'current_roll': game.current_roll if game.current_roll else []
    })


@bp.route('/leaderboard')
@login_required
def leaderboard():
    top_players = db.session.query(
        User,
        db.func.sum(Score.value).label('total_score'),
        db.func.count(db.distinct(Score.game_id)).label('games_played')
    ).join(Score).group_by(User).order_by(db.desc('total_score')).limit(10).all()

    return render_template('game/leaderboard.html', top_players=top_players)


@bp.route('/player_statistics/<int:player_id>')
@login_required
def player_statistics(player_id):
    player = User.query.get_or_404(player_id)
    if not player.player_statistics:
        flash('Ingen statistik tillgänglig för denna spelare.', 'info')
        return redirect(url_for('game.index'))

    return render_template('game/player_statistics.html', player=player)
