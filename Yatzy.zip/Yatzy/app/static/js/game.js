$(document).ready(function () {
  let rollCount = 0;
  let selectedDice = [];
  const gameId = $("#game-container").data("game-id");

  function updateGameState() {
    $.get(`/game_state/${gameId}`, function (gameState) {
      $("#current-player").text(
        `Nuvarande spelare: ${gameState.current_player.name}`
      );
      updateScoreboard(gameState.scores, gameState.categories);
      displayDice(gameState.current_roll);
      if (gameState.is_finished) {
        endGame();
      }
    });
  }

  function rollDice() {
    const rerollIndices = [0, 1, 2, 3, 4].filter(
      (index) => !selectedDice.includes(index)
    );
    $.post(
      `/play/${gameId}`,
      { action: "roll", reroll_indices: rerollIndices },
      function (response) {
        if (response.status === "success") {
          displayDice(response.rolls);
          displayOptions(response.options);
          rollCount++;
          if (rollCount === 3) {
            $("#roll-button").prop("disabled", true);
          }
        } else {
          alert("Ett fel uppstod: " + response.message);
        }
      }
    );
  }

  function displayDice(rolls) {
    const diceContainer = $("#dice-container");
    diceContainer.empty();
    rolls.forEach((roll, index) => {
      const diceImg = $("<img>")
        .addClass("dice")
        .attr("src", `/static/images/value_d6_${roll}_color.png`)
        .attr("data-index", index)
        .attr("data-value", roll)
        .on("click", function () {
          $(this).toggleClass("selected");
          const diceIndex = $(this).data("index");
          if ($(this).hasClass("selected")) {
            selectedDice.push(diceIndex);
          } else {
            selectedDice = selectedDice.filter((i) => i !== diceIndex);
          }
          updateSelectedDiceDisplay();
        });
      if (selectedDice.includes(index)) {
        diceImg.addClass("selected");
      }
      diceContainer.append(diceImg);
    });
    updateSelectedDiceDisplay();
  }

  function updateSelectedDiceDisplay() {
    const helpText =
      selectedDice.length > 0
        ? "Dessa tärningar kommer inte kastas om: " +
          selectedDice.map((i) => i + 1).join(", ")
        : "Klicka på tärningar för att behålla dem mellan kast.";
    $("#help-text").text(helpText);
  }

  function displayOptions(options) {
    const optionsContainer = $("#options-container");
    optionsContainer.empty();
    for (const [category, score] of Object.entries(options)) {
      const button = $("<button>")
        .addClass("btn btn-secondary m-1")
        .text(`${category} (${score})`)
        .on("click", function () {
          saveScore(category, score);
        });
      optionsContainer.append(button);
    }
  }

  function saveScore(category, score) {
    $.post(
      `/play/${gameId}`,
      { action: "save", category: category, score: score },
      function (response) {
        if (response.status === "success") {
          location.reload(); // Ladda om hela sidan
        } else {
          alert("Ett fel uppstod: " + response.message);
        }
      }
    );
  }

  function updateScoreboard(scores, categories) {
    const scoreboard = $("#scoreboard");
    scoreboard.empty();
    const table = $("<table>").addClass("table");
    const headerRow = $("<tr>");
    headerRow.append($("<th>").text("Kategori"));
    for (const playerId in scores) {
      headerRow.append($("<th>").text(scores[playerId].name));
    }
    table.append(headerRow);
    categories.forEach((category) => {
      const row = $("<tr>");
      row.append($("<td>").text(category));
      for (const playerId in scores) {
        row.append($("<td>").text(scores[playerId][category] || "-"));
      }
      table.append(row);
    });
    scoreboard.append(table);
  }

  function endGame() {
    $("#roll-button").prop("disabled", true);
    $("#options-container").empty();
    $("#game-over-message")
      .text("Spelet är avslutat! Se poängbrädet för slutresultatet.")
      .show();
  }

  function resetRound() {
    rollCount = 0;
    selectedDice = [];
    $("#roll-button").prop("disabled", false);
    updateSelectedDiceDisplay();
  }

  $("#roll-button").on("click", function () {
    if (rollCount < 3) {
      rollDice();
    }
  });

  // Initiera spelet
  updateGameState();
  resetRound();
});
