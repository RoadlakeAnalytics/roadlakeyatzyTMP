# Skapa en ny fil: app/constants.py
YATZY_CATEGORIES = [
    'Ettor', 'Tvåor', 'Treor', 'Fyror', 'Femmor', 'Sexor',
    'Ett par', 'Två par', 'Tretal', 'Fyrtal', 'Liten stege', 'Stor stege',
    'Kåk', 'Chans', 'Yatzy'
]
