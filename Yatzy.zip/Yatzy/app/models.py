from app.constants import YATZY_CATEGORIES
from app import db, login_manager
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from datetime import datetime


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))


class Game(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    game_type = db.Column(db.String(20), nullable=False)
    start_time = db.Column(db.DateTime, default=datetime.utcnow)
    end_time = db.Column(db.DateTime)
    current_player_index = db.Column(db.Integer, default=0)
    current_roll = db.Column(db.PickleType, nullable=True)

    players = db.relationship('User', secondary='game_players', lazy='subquery',
                              backref=db.backref('games', lazy=True))
    scores = db.relationship(
        'Score', back_populates='game', cascade='all, delete-orphan')

    def current_player(self):
        return self.players[self.current_player_index]

    def next_player(self):
        self.current_player_index = (
            self.current_player_index + 1) % len(self.players)
        db.session.commit()

    def get_scores(self):
        return {player.id: {score.category: score.value for score in self.scores if score.user_id == player.id}
                for player in self.players}

    def is_finished(self):
        return all(len(scores) == len(YATZY_CATEGORIES) for scores in self.get_scores().values())


class GamePlayers(db.Model):
    game_id = db.Column(db.Integer, db.ForeignKey('game.id'), primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), primary_key=True)


class Score(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    game_id = db.Column(db.Integer, db.ForeignKey('game.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    category = db.Column(db.String(64), nullable=False)
    value = db.Column(db.Integer, nullable=False)

    game = db.relationship('Game', back_populates='scores')
    user = db.relationship('User')


class PlayerStatistics(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    games_played = db.Column(db.Integer, default=0)
    total_score = db.Column(db.Integer, default=0)
    highest_score = db.Column(db.Integer, default=0)
    yatzy_count = db.Column(db.Integer, default=0)

    user = db.relationship('User', backref=db.backref(
        'player_statistics', uselist=False))


class RoadlakeStatistics(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    games_played = db.Column(db.Integer, default=0)
    total_score = db.Column(db.Integer, default=0)
    highest_score = db.Column(db.Integer, default=0)
    special_dice_used_count = db.Column(db.Integer, default=0)

    user = db.relationship('User', backref=db.backref(
        'roadlake_statistics', uselist=False))


class RollHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    game_id = db.Column(db.Integer, db.ForeignKey('game.id'), nullable=False)
    roll_number = db.Column(db.Integer, nullable=False)
    rolls = db.Column(db.PickleType, nullable=False)  # Storing the rolls

    game = db.relationship('Game', backref=db.backref('rolls', lazy=True))
