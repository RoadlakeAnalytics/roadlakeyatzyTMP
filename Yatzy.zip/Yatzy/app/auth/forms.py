# app/auth/forms.py

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Length, EqualTo, ValidationError
from app.models import User

class RegistrationForm(FlaskForm):
    name = StringField('Namn', validators=[DataRequired(), Length(min=1, max=25)])
    password = PasswordField('Lösenord', validators=[DataRequired()])
    password2 = PasswordField(
        'Upprepa lösenord', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Registrera')

    def validate_name(self, name):
        user = User.query.filter_by(name=name.data).first()
        if user is not None:
            raise ValidationError('Använd ett annat namn.')


class LoginForm(FlaskForm):
    name = StringField('Namn', validators=[DataRequired()])
    password = PasswordField('Lösenord', validators=[DataRequired()])
    remember_me = BooleanField('Kom ihåg mig')
    submit = SubmitField('Logga in')
